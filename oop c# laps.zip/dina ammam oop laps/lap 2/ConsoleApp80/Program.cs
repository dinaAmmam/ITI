﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp80
{
    class Program
    {
        static void Main(string[] args)
        {
            //1
            //Console.WriteLine("enter first number");
            //int fn = int.Parse(Console.ReadLine());
            //Console.WriteLine("enter second number");
            //int sn = int.Parse(Console.ReadLine());
            //int sum = fn + sn;
            //if ( fn == sn)
            //{
            //    Console.WriteLine($"sum *3 = {3*sum}");
            //}
            //else
            //{
            //    Console.WriteLine($"sum = {sum}");
            //}

            //2
            //int val1 = 51;
            //Console.WriteLine("please enter number");
            //int n = int.Parse(Console.ReadLine());
            //int diff = Math.Abs(n - val1);
            //if (n > val1)
            //{
            //    Console.WriteLine($"triple of difference = {3 * diff}");
            //}
            //else
            //{
            //    Console.WriteLine($"diff = {diff}");
            //}

            //3
            //Console.WriteLine("please enter number");
            //int a = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int b = int.Parse(Console.ReadLine());
            //int s = a + b;
            //if (a == 30 || b == 30 || s == 30) 
            //{
            //    Console.WriteLine("true");
            //}
            //else
            //{
            //    Console.WriteLine("false");
            //}

            //4
            //Console.WriteLine("please enter number");
            //int value = int.Parse(Console.ReadLine());
            //if (value % 3 == 0 || value % 7 == 0)
            //{
            //    Console.WriteLine("true");
            //}
            //else
            //{
            //    Console.WriteLine("false");
            //}

            //5
            //Console.WriteLine("please enter number");
            //int n1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int n2 = int.Parse(Console.ReadLine());
            //if ((100 <= n1 && n1<= 200) || (100 <= n2 && n2 <= 200))
            //{
            //    Console.WriteLine("true");
            //}
            //else
            //{
            //    Console.WriteLine("false");
            //}

            //6
            //Console.WriteLine("please enter number");
            //int nu1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int nu2 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int nu3 = int.Parse(Console.ReadLine());
            //if ((20 <= nu1 && nu1 <= 50) || (20 <= nu2 && nu2 <= 50) || (20 <= nu3 && nu3 <= 50))
            //{
            //    Console.WriteLine("true");
            //}
            //else
            //{
            //    Console.WriteLine("false");
            //}
            //6 
            //int n0;
            //int n1;
            //int n2;
            //for(int i = 0; i<3; i++)
            //{
            //    Console.Write("Enter Value : \t ");
            //    int n[i] = int.Parse(Console.ReadLine());
            //}

            //7
            //Console.WriteLine("please enter number");
            //int n1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int n2 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int n3 = int.Parse(Console.ReadLine());
            //if( n1> n2 && n1 > n3)
            //{
            //    Console.WriteLine($"{n1} is largest");
            //}
            //else if (n2>n1 && n2 > n3)
            //{
            //    Console.WriteLine($"{n2} is largest");
            //}
            //else
            //{
            //    Console.WriteLine($"{n3} is largest");
            //}

            //8
            //Console.WriteLine("please enter number");
            //int n1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int n2 = int.Parse(Console.ReadLine());
            //int diff1 = Math.Abs(100 - n1);
            //int diff2 = Math.Abs(100 - n2);
            //if( diff1 < diff2)
            //{
            //    Console.WriteLine($"{n1} nearst");
            //}
            //else if ( diff1 > diff2)
            //{
            //    Console.WriteLine($"{n2} nearst");
            //}
            //else
            //{
            //    Console.WriteLine("two numbers are equal");
            //}

            //9
            //Console.WriteLine("please enter number");
            //int n1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int n2 = int.Parse(Console.ReadLine());
            //if( ((40 <= n1 && n1 <= 50) && (40 <= n2 && n2 <= 50)) 
            //    || ((50 <= n1 && n1 <= 60) && (50 <= n2 && n2 <= 60)))
            //{
            //    Console.WriteLine("true");

            //}
            //else
            //{
            //    Console.WriteLine("false");
            //}

            //10
            //Console.WriteLine("please enter number");
            //int n1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int n2 = int.Parse(Console.ReadLine());
            //if(((20 <= n1 && n1 <= 30) && (20 <= n2 && n2 <= 30) && (n1 != n2)))
            //{
            //    if(n1 > n2)
            //    {
            //        Console.WriteLine($"{n1} largest");
            //    }
            //    else
            //    {
            //        Console.WriteLine($"{n2} largest");

            //    }
            //}
            //else
            //{
            //    Console.WriteLine("0");
            //}

            //11-Write a C# Sharp program to create a new string which is n (non-negative
            //integer) copies of a given string.
            //Console.WriteLine("enter string");
            //string s = Console.ReadLine();
            //Console.WriteLine("enter number");
            //int n = int.Parse(Console.ReadLine());
            //for(int i= 0; i<n; i++)
            //{
            //    Console.Write($"{s}");
            //}

            //12-Write a C# Sharp program that accept two integers and return true if either
            //one is 5 or their sum or difference is 5.
            //Console.WriteLine("please enter number");
            //int n1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int n2 = int.Parse(Console.ReadLine());
            //int sum = n1 + n2;
            //int diff = Math.Abs(n1 - n2);
            //if(n1 == 5 || n2 == 5 || sum ==5 || diff == 5)
            //{
            //    Console.WriteLine("true");
            //}
            //else
            //{
            //    Console.WriteLine("false");
            //}

            //13- Write a C# Sharp program to check if a given non-negative given number is a
            //multiple of 3 or 7, but not both.
            //Console.WriteLine("please enter number");
            //int n1 = int.Parse(Console.ReadLine());
            //if((n1 % 3 ==0) && (n1 % 7 !=0) && (n1>0))
            //{
            //    Console.WriteLine("true");
            //}
            //else if ((n1 % 3 != 0) && (n1 % 7 == 0) && (n1 > 0))
            //{
            //    Console.WriteLine("true");
            //}
            //else
            //{
            //    Console.WriteLine("false");
            //}

            //14- Write a C# Sharp program to check whether a given number is divisible by 3
            //return "Fizz" and return "Buzz" if it divisible by 5 and return "FizzBuzz" If it
            //divisible by 3 and 5
            //Console.WriteLine("please enter number");
            //int n = int.Parse(Console.ReadLine());
            //if(n%3 == 0 && n%5 != 0)
            //{
            //    Console.WriteLine("Fizz");
            //}
            //else if (n % 5 == 0 && n % 3 != 0)
            //{
            //    Console.WriteLine("Buzz");
            //}
            //else if (n % 5 == 0 && n % 3 == 0)
            //{
            //    Console.WriteLine("FizzBuzz");
            //}
            //else
            //{
            //    Console.WriteLine("non div");
            //}

            //15- Write a C# Sharp program to check if it is possible to add two integers to get
            //the third integer from three given integers.
            //Console.WriteLine("please enter number");
            //int n1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int n2 = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int n3 = int.Parse(Console.ReadLine());
            //if ((n1+n2 == n3) || (n2+n3 == n1) || (n1+n3 == n2))
            //{
            //    Console.WriteLine("true");
            //}
            //else
            //{
            //    Console.WriteLine("false");
            //}

            //16- Write a C# Sharp program to check if y is greater than x, and z is greater than
            //y from three given integers x, y, z.
            //Console.WriteLine("please enter number");
            //int x = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int y = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int z = int.Parse(Console.ReadLine());
            //if((y > x) && (z > y))
            //{
            //    Console.WriteLine("true");
            //}
            //else
            //{
            //    Console.WriteLine("false");
            //}

            //17- Create Multiplication Table
            //Console.WriteLine("please enter number");
            //int x = int.Parse(Console.ReadLine());
            //for(int i =1; i<11; i++)
            //{
            //    Console.WriteLine($"{x} * {i} = {x * i}");
            //}
            //18- receive 3 positive numbers from user and display max and min of them
            //Console.WriteLine("please enter number");
            //int x = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int y = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter number");
            //int z = int.Parse(Console.ReadLine());
            //if((x>y) && (x > z))
            //{
            //    Console.WriteLine($"{x} max");
            //    if (y > z)
            //    {
            //        Console.WriteLine($"{z} min");
            //    }
            //    else
            //    {
            //        Console.WriteLine($"{y} min");
            //    }
            //}
            //else if ((y>x) && (y > z))
            //{
            //    Console.WriteLine($"{y} max");
            //    if (x > z)
            //    {
            //        Console.WriteLine($"{z} min");
            //    }
            //    else
            //    {
            //        Console.WriteLine($"{x} min");
            //    }
            //}
            //else
            //{
            //    Console.WriteLine($"{z} max");
            //    if (x > y)
            //    {
            //        Console.WriteLine($"{y} min");
            //    }
            //    else
            //    {
            //        Console.WriteLine($"{x} min");
            //    }

            //}
            //19- receive positive numbers from user until summation of them reached or exceed 400
            //int sum = 0;
            //while(sum < 400)
            //{
            //    Console.WriteLine("enter num");
            //    sum += int.Parse(Console.ReadLine());
            //}
            //Console.WriteLine($"sum = {sum}");

            //20-display Selection Menu for user
            //#region
            //char c;
            //do
            //{
            //    Console.Clear();
            //    Console.WriteLine("+ summation \n - subtraction \n / division \n * multiplcation \n e exist");
            //    c = char.Parse(Console.ReadLine());
            //    switch (c)
            //    {
            //        case '+':
            //            Console.WriteLine("enter num");
            //            int y = int.Parse(Console.ReadLine());
            //            Console.WriteLine("enter num");
            //            int x = int.Parse(Console.ReadLine());
            //            int sum = x + y;
            //            Console.WriteLine($"sum = {sum}");
            //            break;
            //        case '-':
            //            Console.WriteLine("enter num");
            //            int n = int.Parse(Console.ReadLine());
            //            Console.WriteLine("enter num");
            //            int z = int.Parse(Console.ReadLine());
            //            int sub = Math.Abs(n -z);
            //            Console.WriteLine($"sub = {sub}");
            //            break;
            //        case '/':
            //            Console.WriteLine("enter num");
            //            int m = int.Parse(Console.ReadLine());
            //            Console.WriteLine("enter num");
            //            int k = int.Parse(Console.ReadLine());
            //            int div = m - k ;
            //            Console.WriteLine($"div = {div}");
            //            break;
            //        case '*':
            //            Console.WriteLine("enter num");
            //            int n1 = int.Parse(Console.ReadLine());
            //            Console.WriteLine("enter num");
            //            int n2 = int.Parse(Console.ReadLine());
            //            int mul = n1 * n2;
            //            Console.WriteLine($"mul = {mul}");
            //            break;
            //        case 'E':
            //        case 'e':
            //            Console.WriteLine("exist");
            //            break;
            //    }
            //    Console.ReadKey();
            //} while (c != 'e' && c != 'E');
            //#endregion
            #region
            //21- receive two different positive numbers and display even , odd numbers between them , then display 
            //summation of odd ones and even ones , then display absolute difference between two summations.
            
            //Console.WriteLine("please enter positive number");
            //int fn = int.Parse(Console.ReadLine());
            //Console.WriteLine("please enter positive number");
            //int sn = int.Parse(Console.ReadLine());

            //int[] numbers = new int[(sn - fn)];
            //int[] even = new int[(sn - fn)];
            //int[] odd = new int[(sn - fn)];
            //int evenResult = 0;
            //int oddResult = 0;
            //if (sn > 0 && fn > 0 && sn > fn)
            //{
            //    for (int i = fn; i <=Math.Abs((sn-fn)) ; i++)
            //    {
            //        if (i % 2 == 0)
            //        {
            //            even[i] = i;
            //            evenResult += i;
            //        }
            //        else
            //        {
            //            odd[i] = i;
            //            oddResult += i;
            //        }
            //    }

            //    Console.WriteLine($"{even}");
            //    int diff = Math.Abs(evenResult - oddResult);
            //    Console.WriteLine(diff);

            //}


            //else {
            //    Console.WriteLine("invalid num"); }
             
    
          

            #endregion
        








        }
    }
}
